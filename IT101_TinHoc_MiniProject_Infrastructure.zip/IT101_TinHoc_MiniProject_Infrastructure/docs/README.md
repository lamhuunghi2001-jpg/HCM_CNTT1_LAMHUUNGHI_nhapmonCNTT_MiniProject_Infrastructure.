# GreenTech Infrastructure Mini Project

## 1. Giới thiệu
GreenTech Infrastructure là dự án thực hành quản lý hạ tầng cơ bản cho startup GreenTech. Dự án gồm tổ chức thư mục, lọc log, viết tài liệu vận hành và quản lý thông tin linh kiện bằng Excel.

## 2. Cấu trúc thư mục
```text
greentech-system/
├── docs/
│   ├── README.md
│   └── srs-he-thong.docx
├── scripts/
│   └── auto_report.bat
├── data/
│   ├── log-he-thong.log
│   └── quan-ly-thiet-bi.xlsx
├── backup/
│   └── bao-cao-su-co.txt
└── .env.example
```

## 3. Cách chạy script (Windows)
1. Giải nén dự án và mở Command Prompt tại thư mục gốc.
2. Chạy lệnh:
```bat
scripts\auto_report.bat
```
3. Xem báo cáo được ghi trong `backup/bao-cao-su-co.txt`.

Script chỉ đọc log và ghi thêm báo cáo; không có lệnh xóa tệp. Trước khi chạy, script kiểm tra sự tồn tại của tệp log và thư mục backup.

## 4. Checklist kiểm tra trạm cảm biến
- [ ] Kiểm tra mã trạm và mã linh kiện.
- [ ] Kiểm tra dung lượng RAM được ghi đúng.
- [ ] Kiểm tra ngày lắp đặt.
- [ ] Đối chiếu tên thiết bị bằng VLOOKUP.
- [ ] Kiểm tra các dòng `CRITICAL` và `ERROR` trong báo cáo.

## 5. Bảng thông số phần cứng mẫu

| Thiết bị | Thông số mẫu | Mục đích |
|---|---|---|
| CPU | 4 nhân | Xử lý dữ liệu cảm biến |
| RAM | 8 GB | Chạy dịch vụ thu thập dữ liệu |
| SSD | 256 GB | Lưu hệ điều hành và dữ liệu tạm |

Các thông số chỉ là dữ liệu minh họa, không đại diện cho thiết bị đang vận hành thật.

## 6. Tính thời gian tải log
Công thức gần đúng:
`Thời gian (giây) = Dung lượng (MB) × 8 / Tốc độ mạng (Mbps)`

Ví dụ, tải tệp 500 MB qua đường truyền 100 Mbps:
`500 × 8 / 100 = 40 giây` (chưa tính hao hụt mạng).

## 7. Excel
Tệp `data/quan-ly-thiet-bi.xlsx` có hai sheet:
- `danh-muc-linh-kien`: danh mục thiết bị, mã linh kiện là khóa chính.
- `trang-thai-tram`: danh sách trạm, mã linh kiện là khóa ngoại.

Cột tên thiết bị sử dụng VLOOKUP với đối sánh chính xác. Hàm TRIM được dùng để loại bỏ khoảng trắng thừa khỏi mã linh kiện.

## 8. Lưu ý an toàn
- `.env.example` chỉ chứa giá trị giả định; không đưa mật khẩu thật lên GitHub.
- Không chạy lệnh xóa hàng loạt như `del /f /s /q` trong bài thực hành.
- Log và thông số trong dự án đều là dữ liệu mẫu.
