@echo off
setlocal
REM GreenTech - log report script. Read-only for source log; no delete commands.

set "ROOT=%~dp0.."
set "LOG_FILE=%ROOT%\data\log-he-thong.log"
set "BACKUP_DIR=%ROOT%\backup"
set "REPORT_FILE=%BACKUP_DIR%\bao-cao-su-co.txt"

REM AUDIT: validate expected paths before processing.
if not exist "%LOG_FILE%" (
    echo [AUDIT FAILED] Khong tim thay tep log: "%LOG_FILE%"
    exit /b 1
)
if not exist "%BACKUP_DIR%\" (
    echo [AUDIT FAILED] Khong tim thay thu muc backup.
    exit /b 1
)

echo ================================================>> "%REPORT_FILE%"
echo GREEN TECH - BAO CAO SU CO>> "%REPORT_FILE%"
echo Thoi gian tao: %DATE% %TIME%>> "%REPORT_FILE%"
echo Nguon log: data\log-he-thong.log>> "%REPORT_FILE%"
echo Cac dong CRITICAL va ERROR:>> "%REPORT_FILE%"
echo ------------------------------------------------>> "%REPORT_FILE%"

REM Pipe reads the file as a stream; FINDSTR filters matching lines without loading
REM the entire 500 MB log into a script variable. Output is appended using >>.
type "%LOG_FILE%" | findstr /I /C:"CRITICAL" /C:"ERROR" >> "%REPORT_FILE%"

if errorlevel 2 (
    echo [AUDIT WARNING] FINDSTR gap loi khi loc log.>> "%REPORT_FILE%"
    exit /b 2
)

echo.>> "%REPORT_FILE%"
echo Ket thuc bao cao.>> "%REPORT_FILE%"
echo [OK] Da ghi them ket qua vao backup\bao-cao-su-co.txt
endlocal
